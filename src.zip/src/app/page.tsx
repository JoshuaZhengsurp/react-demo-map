import Matting from "@/components/matting/Matting";

export default function Home() {
  return (
    <div className="w-[100%] h-[100vh] flex items-center">
      <Matting />
    </div>
  );
}
