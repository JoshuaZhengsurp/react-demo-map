import { INITIAL_HARDNESS, INITIAL_RADIUS } from "@/const";
import { useState } from "react";

export function useMatting(): Matting {
  const [picFile, setPicFile] = useState<null | File>(null);
  const [isErasing, setIsErasing] = useState<boolean>(false);
  const [radius, setRadius] = useState(INITIAL_RADIUS);
  const [hardness, setHardness] = useState(INITIAL_HARDNESS);

  const setMatState = (key: string, value: any) => {
    const setters: Record<string, any> = {
      picFile: setPicFile,
      isErasing: setIsErasing,
      radius: setRadius,
      hardness: setHardness,
    };

    const setter = setters[key];
    setter && setter(value);
  };

  return {
    picFile,
    isErasing,
    radius,
    hardness,
    setMatState,
  };
}
